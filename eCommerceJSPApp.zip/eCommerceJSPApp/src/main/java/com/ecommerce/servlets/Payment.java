package com.ecommerce.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ecommerce.services.CalculateMethodClass;

/**
 * Servlet implementation class Payment
 */
@WebServlet("/Payment")
public class Payment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Payment() {
        super();
        // TODO Auto-generated constructor stub
    }


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
int i=1;
		
		Enumeration<String> eitems= null;
		HttpSession session=request.getSession(false);
		eitems= request.getParameterNames();
		PrintWriter out=response.getWriter();
		CalculateMethodClass cm=new CalculateMethodClass();
		while(eitems.hasMoreElements()) {
			
			String items=(String)eitems.nextElement();
//			System.out.println(items);
			session.setAttribute("item"+i, items);
			i++;
		}
		session.setAttribute("counter", i + "");
//		System.out.println("Payment");
		System.out.println(i);
//		RequestDispatcher dis=request.getRequestDispatcher("calculate");
//		dis.include(request, response);
//		
		
		String username = (String) session.getAttribute("name");
		String eitems1[]=new String[i-1];
		int price=0;
		for(int j=1;j<i;j++) {
			//System.out.println(i);
			eitems1[j-1]=(String) session.getAttribute("item"+j);
			//System.out.println(eitems[i-1]);
			price=price + cm.getPrice(eitems1[j-1]);
			
		}
			
			//out.print(username+",Please pay:"+price);
			out.print("<html><head><title>Payment</title></head><body>"+username+", Please pay:"+price);
			out.print("<form action='Logout' method='post'><br><br><input type='submit'  value='Logout'></form></body>");
			
			
			
	}

}
