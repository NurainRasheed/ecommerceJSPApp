package com.ecommerce.services;

public class CalculateMethodClass {
	public int getPrice(String value) {
		int price=0;
		switch (value){
		case "item1" : price =1000;
		break;
		
		case "item2" : price =500;
		break;
			
		case "item3" : price =400;
		break;
			
		case "item4" : price =500;
		break;
		case "item5" : price =100;
		break;
		}
		
		return price;
	}
}
